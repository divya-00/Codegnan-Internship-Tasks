import {Fragment} from 'react'
function Frag(){
	return(
		<Fragment>
			<h1>Good evening</h1>
		</Fragment>
	)
}
export default Frag