function NotFound(){
	return <p>NotFound page</p>
}

export default NotFound